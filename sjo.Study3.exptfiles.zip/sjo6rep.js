define(['managerAPI'], function(Manager){

	// This code is responsible for styling the piQuest tasks as panels (like piMessage)
	// Don't touch unless you know what you're doing
	var css = '[pi-quest]{background-color: #fff;border: 1px solid transparent;border-radius: 4px;box-shadow: 0 1px 1px rgba(0, 0, 0, 0.05);margin-bottom: 20px;border-color: #bce8f1;padding:15px;}';
	window.angular.element(document).find('head').prepend('<style type="text/css">@charset "UTF-8";' + css + '</style>');

	var API = new Manager();

	
	
	API.setName('mgr');
	API.addGlobal({baseURL : '/implicit/user/kratliff/uflliz/newPI/newpi2/images/'});
	API.addTasksSet({
		instructions: [{type:'message', buttonText:'Continue'}], 
		
		consent : [{inherit:'instructions', name:'consent', templateUrl: 'consent.jst', title:'Consent', 
			piTemplate:true, header:'Consent Agreement: Implicit Social Cognition on the Internet'}],
		
	
		instructions1 : [{
			inherit:'instructions', name:'realstart', templateUrl: 'instructions1.jst', title:'Instructions', 
			piTemplate:true,
		}], 

		
	
			lowses: [{type: 'quest', name: 'lowses', scriptUrl: 'lowses.js'}],
			
			highses: [{type: 'quest', name: 'highses', scriptUrl: 'highses.js'}],
		
		
		instructions2 : [{
			inherit:'instructions', name:'instructions2', templateUrl: 'instructions2.jst', piTemplate:true,}], 


		instructions3 : [{
			inherit:'instructions', name:'instructions3', templateUrl: 'instructions3.jst', piTemplate:true,}], 

		
		retribjorient: [{type: 'quest', name: 'retribjorient', scriptUrl: 'retribjorient.js'}],
				
		sdo: [{type: 'quest', name: 'sdo', scriptUrl: 'sdo.js'}],
		
		
                instiatrace: [{inherit:'instructions', name:'iatinstrace', templateUrl: 'instiatrace.jst', title:'IAT Instructions',
                    piTemplate:true, header:'Implicit Association Test'}],
                    
		
		iatrace: [{type: 'pip', name: 'iatrace', version: '0.3', scriptUrl: 'iatrace.js'}], 
		     
		     
		debriefing : [{type:'message',name:'lastpage', templateUrl: 'debriefing.jst', piTemplate:'debrief', last:true}]
	});

	

	API.addSequence([
		{inherit:'consent'},
		{inherit:'instructions1'},
		{mixer:'choose',
		 n:1,
		data : [{inherit:'highses'},
			{inherit:'lowses'},
			]},
      
      		{mixer:'random',
		data : [
			{mixer:'wrapper',
				data : [
				{inherit:'instructions2'},		
				{inherit:'retribjorient'},
				]},
		
			{mixer:'wrapper',
				data : [
				{inherit:'instructions3'},		
				{inherit:'sdo'},
				]},
		]},
		
		
		{inherit:'instiatrace'},
		{inherit:'iatrace'},	
		
		{inherit:'debriefing'},]);

	return API.script;
});
