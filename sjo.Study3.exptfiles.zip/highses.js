define(['questAPI'], function(Quest){

	var API = new Quest();
	API.addCurrent({incorrects:0, go:'a financial executive'});

	API.addQuestionsSet('trickQuestion',
	{
		type: 'selectOne',
		autoSubmit:true,
		required : true,
		stem: 'In the scenario you just read, what is Nick`s job?<br>To respond, double click your response, or click your response and click Submit.',
		name:'forcechoice',
		answers : ['a financial executive', 'a fast-food cashier'],
		onSubmit: function(log, current){
			if (log.response !== 'a financial executive')
			{
				API.addCurrent({incorrects:API.getCurrent().incorrects+1, go:'a fast-food cashier'});
			}
			else
			{
				API.addCurrent({go:'a financial executive'});
			}
		}
	});

	API.addQuestionsSet('trickQuestions',
	{
		inherit: 'trickQuestion',
		stem: 'In the scenario you just read, what is Nick`s job?<br></b>To respond, double click your response or click your response and click Submit.<br/><br/>',
		name:'forcechoice<%=current.incorrects%>'
	});

	/**
	Pages
	**/

	API.addSequence([
		{
		    questions:[
        		{type: 'info',description: '<p class="lead">One day, Nick is on his way home from his job as a financial executive. Nick walks to the garage, finds his car, a new Jaguar XK roadster, and heads to his home, a lakefront estate in a gated community. On the way, Nick gets angry at the traffic. While traffic is stopped, Nick starts shouting at another driver. He then gets out of his car, smashes the other driver`s window, and assaults him.</p>'},
        		{inherit: 'trickQuestion'}
    	    ]
		},
        {
            mixer : 'branch',
        	conditions : [{compare:'current.go', to:'a fast-food cashier'}],
        	data : [{
        		header : 'Please read the story again and answer correctly.',
        		questions: [
        		    {type: 'info',description: '<p class="lead">One day, Nick is on his way home from his job as a financial executive. Nick walks to the garage, finds his car, a new Jaguar XK roadster, and heads to his home, a lakefront estate in a gated community. On the way, Nick gets angry at the traffic. While traffic is stopped, Nick starts shouting at another driver. He then gets out of his car, smashes the other driver`s window, and assaults him.</p>'},
        		    {inherit: 'trickQuestions', correct:true, correctValue: 'a financial executive', required:false}
        		]
        	}]
        }
	]);

	return API.script;
});