define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
		numericValues:true, 
          answers: [
                 {text: 'Strongly Agree',value:7},
                 {text: 'Agree',value:6},
                 {text: 'Slightly Agree',value:5},
                 {text: 'Neither agree nor disagree',value:4},
                  {text:'Slightly Disagree',value:3},
                   {text:'Disagree',value:2},
                  {text:'Strongly Disagree',value:1},
               ]
		}]);
	
	
    API.addPagesSet('progressBar', [
	{progressBar: 'To respond, double click your response, or click your response and click Submit.',
numbered: false,
        decline: true}]);

	
		
API.addSequence([

{mixer:'random',data:[  
     
	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'retribjorient1',
               stem: "As a matter of fairness, Nick should be penalized."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'retribjorient2',
               stem: "The only way to restore justice is to punish Nick."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'retribjorient3',
               stem: "Justice will be served when Nick is penalized."}]},
	 
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'retribjorient4',
               stem: "Only punishment will restore the justice disrupted by Nick's crime."}]},

	       
        {inherit: 'progressBar',
         questions: [
	{inherit: 'singleChoice',
		name: 'retribjorient5',
               stem: "For the sake of justice, some degree of suffering has to be inflicted on Nick."}]},


        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient6',
               stem: "Nick deserves to be penalized."}]},
	 

        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient7',
               stem: "For Nick, infliction of suffering is an important part of punishment."}]},
	 
        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient8',
               stem: "For Nick, punishment without suffering is no punishment."}]},

        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient9',
               stem: "For Nick, punishment is deserved suffering."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient10',
               stem: "We should punish to get even with Nick."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient11',
               stem: "Society should punish Nick to get back at him."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient12',
               stem: "Society has the right to take revenge on Nick."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient13',
               stem: "Justice requires a punishment as severe as Nick's offense."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient14',
               stem: "The purpose of punishment should be to make Nick pay for his crime."}]},

                       {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'retribjorient15',
               stem: "Nick should be punished to make him repay his debt to society."}]},

    ]},]);

 
return API.script;
});
