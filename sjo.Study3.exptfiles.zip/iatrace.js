define(['/implicit/common/all/js/pip/piscripts/iat/iat4.js'], function(iatExtension){
	return iatExtension({
		category1 : {
			name : 'White people', 
			title : {
				media : {word : 'White people'}, 
				css : {color:'#0000FF','font-size':'2em'}, 
				height : 4 //Used to position the "Or" in the combined block.
			}, 
			stimulusMedia : [ //Stimuli content as PIP's media objects
				{image: 'wf1.jpg'},
				{image: 'wf2.jpg'},
				{image: 'wm1.jpg'},
				{image: 'wm2.jpg'}
			], 
			//Stimulus css
			stimulusCss : {color:'#0000FF','font-size':'1.8em'} 
		},	
		category2 :	{
			name : 'Black people', 
			title : {
				media : {word : 'Black people'}, 
				css : {color:'#0000FF','font-size':'2em'}, 
				height : 4 //Used to position the "Or" in the combined block.
			}, 
			stimulusMedia : [ //Stimuli content as PIP's media objects
				{image: 'bf1.jpg'},
				{image: 'bf2.jpg'},
				{image: 'bm1.jpg'},
				{image: 'bm2.jpg'}
			], 
			//Stimulus css
			stimulusCss : {color:'#0000FF','font-size':'1.8em'}
		},
		attribute2 : 
		{
			name : 'Good words', //Will appear in the data.
			title : {
				media : {word : 'Good words'}, //Name of the category presented in the task.
				css : {color:'#31b404','font-size':'2em'}, //Style of the category title.
				height : 4 //Used to position the "Or" in the combined block.
			}, 
			stimulusMedia : [ //Stimuli content as PIP's media objects
				{word: 'Nice'},
				{word: 'Heaven'},
				{word: 'Happy'},
				{word: 'Pleasure'}
			], 
			//Stimulus css (style)
			stimulusCss : {color:'#31b404','font-size':'1.8em'}
		},
		attribute1 : 
		{
			name : 'Bad words', //Will appear in the data.
			title : {
				media : {word : 'Bad words'}, //Name of the category presented in the task.
				css : {color:'#31b404','font-size':'2em'}, //Style of the category title.
				height : 4 //Used to position the "Or" in the combined block.
			}, 
			stimulusMedia : [ //Stimuli content as PIP's media objects
				{word: 'Nasty'},
				{word: 'Hell'},
				{word: 'Horrible'},
				{word: 'Rotten'}
			], 
			//Stimulus css
			stimulusCss : {color:'#31b404','font-size':'1.8em'}
		},

		base_url : {//Where are your images at?
			image : '/implicit/user/kratliff/ufljohn/privstudies/priv6/images'
		},
		
		//attribute1, and attribute2 will be replaced with the name of attribute1 and attribute2.
		//categoryA is the name of the category that is found to be associated with attribute1,
		//and categoryB is the name of the category that is found to be associated with attribute2.
		fb_strong_Att1WithCatA_Att2WithCatB : 'Your data suggest strong automatic preference for categoryB over categoryA.',
		fb_moderate_Att1WithCatA_Att2WithCatB : 'Your data suggest moderate automatic preference for categoryB over categoryA.',
		fb_slight_Att1WithCatA_Att2WithCatB : 'Your data suggest weak automatic preference for categoryB over categoryA.',
		fb_equal_CatAvsCatB : 'Your data suggest no automatic preference between categoryA and categoryB.',
	});
});
