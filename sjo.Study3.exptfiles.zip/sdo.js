define(['questAPI'], function(Quest){

	var API = new Quest();

	API.addSettings('logger', 
	{url: '/implicit/PiQuest',});

	API.addQuestionsSet('singleChoice', [
		{type: 'selectOne',
		autoSubmit: true,
          answers: [
                 {text: 'Strongly agree',value:7},
                 {text: 'Moderately agree',value:6},
                 {text: 'Slightly agree',value:5},
                  {text:'Neither disagree or agree',value:4},
                   {text:'Slightly disagree',value:3},
                  {text:'Moderately disagree',value:2},
                  {text:'Strongly disagree',value:1}
               ]
		}]);
	
		API.addQuestionsSet('text', [
		{type: 'text'}]);

		API.addQuestionsSet('intro', [
		{type: 'textNumber'}]);

		API.addQuestionsSet('singleChoicedrop', [
		{type: 'dropdown'}]);

		API.addQuestionsSet('multiChoice', [
		{type: 'selectMulti', decline: true}]);

   API.addQuestionsSet('boolean', [
      {type: 'selectOne',
         autoSubmit: true,
         buttons: true,
         answers : [
            {text:'Yes', value:1},
            {text:'No', value:0}
         ]}]);
	
	
	
	API.addPagesSet('progressBar', [
	{progressBar: 'To respond, double click your response, or click your response and click Submit.',
	numbered: false,
        decline: true}]);

	
		


	API.addSequence([
	
      
      
{mixer:'random',data:[  
     


	{inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'socialdom1',
               stem: "Some groups of people are simply inferior to other groups."}]},
            
	    
	{inherit: 'progressBar',
         questions: [       
            {inherit: 'singleChoice',
               name: 'socialdom2',
               stem: "It's OK if some groups have more of a chance in life than others."}]},
	 
	 
        {inherit: 'progressBar',
         questions: [
               {inherit: 'singleChoice',
               name: 'socialdom3',
               stem: "To get ahead in life, it is sometimes necessary to step on other groups.",}]},
	 
	 
	 
        {inherit: 'progressBar',
         questions: [
            {inherit: 'singleChoice',
               name: 'socialdom4',
               stem: "Inferior groups should stay in their place."}]},

	       
        {inherit: 'progressBar',
         questions: [
	{inherit: 'singleChoice',
		name: 'socialdom5',
               stem: "Group equality should be our ideal.",}]},


        {inherit: 'progressBar',
         questions: [
        {inherit: 'singleChoice',
               name: 'socialdom6',
               stem: "We should do what we can to equalize conditions for different groups.",
             }]},
	 

    ]},]);
 

return API.script;
});
