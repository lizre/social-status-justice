define(['questAPI'], function(Quest){

	var API = new Quest();
	API.addCurrent({incorrects:0, go:'a fast-food cashier'});

	API.addQuestionsSet('trickQuestion',
	{
		type: 'selectOne',
		autoSubmit:true,
		required : true,
		stem: 'In the scenario you just read, what is Nick`s job?<br>To respond, double click your response, or click your response and click Submit.',
		name:'forcechoice',
		answers : ['a fast-food cashier', 'a financial executive'],
		onSubmit: function(log, current){
			if (log.response !== 'a fast-food cashier')
			{
				API.addCurrent({incorrects:API.getCurrent().incorrects+1, go:'a financial executive'});
			}
			else
			{
				API.addCurrent({go:'a fast-food cashier'});
			}
		}
	});

	API.addQuestionsSet('trickQuestions',
	{
		inherit: 'trickQuestion',
		stem: 'In the scenario you just read, what is Nick`s job?<br></b>To respond, double click your response or click your response and click Submit.<br/><br/>',
		name:'forcechoice<%=current.incorrects%>'
	});

	/**
	Pages
	**/

	API.addSequence([
		{
		    questions:[
        		{type: 'info',description: '<p class="lead">One day, Nick is on his way home from his job as an on-call fast-food cashier. Nick walks to the parking lot, finds his car, an old Toyota Corolla he leases, and heads to his home, an apartment in a subsidized housing block. On the way, Nick gets angry at the traffic. While traffic is stopped, Nick starts shouting at another driver. He then gets out of his car, smashes the other driver`s window, and assaults him.</p>'},
        		{inherit: 'trickQuestion'}
    	    ]
		},
        {
            mixer : 'branch',
        	conditions : [{compare:'current.go', to:'a financial executive'}],
        	data : [{
        		header : 'Please read the story again and answer correctly.',
        		questions: [
        		    {type: 'info',description: '<p class="lead">One day, Nick is on his way home from his job as an on-call fast-food cashier. Nick walks to the parking lot, finds his car, an old Toyota Corolla he leases, and heads to his home, an apartment in a subsidized housing block. On the way, Nick gets angry at the traffic. While traffic is stopped, Nick starts shouting at another driver. He then gets out of his car, smashes the other driver`s window, and assaults him.</p>'},
        		    {inherit: 'trickQuestions', correct:true, correctValue: 'a fast-food cashier', required:false}
        		]
        	}]
        }
	]);

	return API.script;
});